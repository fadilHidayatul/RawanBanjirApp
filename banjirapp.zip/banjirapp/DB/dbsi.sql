-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 10:31 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(30) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `daerah`
--

CREATE TABLE `daerah` (
  `id_daerah` int(11) NOT NULL,
  `kode_daerah` varchar(5) NOT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_kecamatan` int(11) NOT NULL,
  `id_kelurahan` int(11) NOT NULL,
  `luas_bahaya` double NOT NULL,
  `foto` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daerah`
--

INSERT INTO `daerah` (`id_daerah`, `kode_daerah`, `id_kelas`, `id_kecamatan`, `id_kelurahan`, `luas_bahaya`, `foto`, `lat`, `lng`, `id_admin`) VALUES
(1, 'BT01', 3, 1, 1, 112.05, 'bungus_barat.jpg', '-1.020048', '100.405566', 1),
(2, 'BT02', 2, 1, 2, 55.17, 'bungus_selatan.jpg', '-1.034006', '100.417607', 1),
(3, 'BT03', 2, 1, 3, 122.76, 'bungus_timur.jpg', '-1.008912', '100.434809', 1),
(4, 'BT04', 2, 1, 4, 20.43, 'TK_Selatan.jpg', '-1.036065', '100.414431', 1),
(5, 'BT05', 2, 1, 5, 36.36, 'TK_Tengah.jpg', '-1.085066', '100.391851', 1),
(6, 'BT06', 3, 1, 6, 47.25, 'TK_Utara.jpg', '-1.046708', '100.429573', 1),
(7, 'KT01', 3, 2, 7, 371.7, 'air_pacah.jpg', '-0.869252', '100.383879', 1),
(8, 'KT02', 3, 2, 8, 653.22, 'balai_gadang.jpg', '-0.787049', '100.394028', 1),
(9, 'KT03', 3, 2, 9, 246.42, 'batang_kabung.jpg', '-0.851684', '100.336324', 1),
(10, 'KT04', 2, 2, 10, 844.47, 'batipuh_panjang.jpg', '-0.817197', '100.333246', 1),
(11, 'KT05', 3, 2, 11, 328.95, 'bungo_pasang.jpg', '-0.861331', '100.349775', 1),
(12, 'KT06', 3, 2, 12, 380.7, 'tunggul_hitam.jpg', '-0.876964', '100.367872', 1),
(13, 'KT07', 3, 2, 13, 607.77, 'koto_panjang.jpg', '-0.853925', '100.368577', 1),
(14, 'KT08', 3, 2, 14, 327.33, 'koto_pulai.jpg', '-0.843570', '100.348860', 1),
(15, 'KT09', 3, 2, 15, 460.8, 'lubuk_buaya.jpg', '-0.828545', '100.322498', 1),
(16, 'KT10', 2, 2, 16, 260.1, 'lubuk_minturun.jpg', '-0.809517', '100.452320', 1),
(17, 'KT11', 3, 2, 17, 498.24, 'padang_sarai.jpg', '-0.816895', '100.304676', 1),
(18, 'KT12', 3, 2, 18, 468.18, 'parupuk_tabing.jpg', '-0.879374', '100.345520', 1),
(19, 'KT13', 3, 2, 19, 240.84, 'pasir_tigo.jpg', '-0.839644', '100.318833', 1),
(20, 'KU01', 3, 3, 20, 118.98, 'ampang.jpg', '-0.921648', '100.376323', 1),
(21, 'KU02', 3, 3, 21, 138.78, 'anduring.jpg', '-0.932895', '100.385286', 1),
(22, 'KU03', 3, 3, 22, 649.35, 'gunung_sarik.jpg', '-0.883216', '100.408381', 1),
(23, 'KU04', 3, 3, 23, 245.16, 'kalumbuk.jpg', '-0.910874', '100.388550', 1),
(24, 'KU05', 3, 3, 24, 331.02, 'korong_gadang.jpg', '-0.915512', '100.407399', 1),
(25, 'KU06', 3, 3, 25, 481.5, 'kuranji.jpg', '-0.912660', '100.419403', 1),
(26, 'KU07', 3, 3, 26, 179.19, 'lubuk_lintah.jpg', '-0.923109', '100.387655', 1),
(27, 'KU08', 3, 3, 27, 393.48, 'ambacang.jpg', '-0.929155', '100.404341', 1),
(28, 'KU09', 3, 3, 28, 398.43, 'sungai_sapih.jpg', '-0.891465', '100.390632', 1),
(29, 'LB01', 3, 4, 29, 36, 'banuaran.jpg', '-0.968283', '100.388438', 1),
(30, 'LB02', 3, 4, 30, 58.32, 'batuang_taba.jpg', '-0.964873', '100.402899', 1),
(31, 'LB03', 3, 4, 31, 57.51, 'cengkeh.jpg', '-0.951324', '100.418857', 1),
(32, 'LB04', 2, 4, 32, 5.58, 'gates.jpg', '-0.992227', '100.383915', 1),
(33, 'LB05', 3, 4, 33, 24.57, 'gurun_laweh.jpg', '-0.958968', '100.389061', 1),
(34, 'LB06', 3, 4, 34, 66.06, 'kampung_baru.jpg', '-0.958050', '100.417763', 1),
(35, 'LB07', 3, 4, 35, 96.21, 'kampung_jua.jpg', '-0.965357', '100.418377', 1),
(36, 'LB08', 2, 4, 36, 6.3, 'koto_baru.jpg', '-0.965882', '100.381103', 1),
(37, 'LB09', 3, 4, 37, 97.74, 'lubuk_begalung.jpg', '-0.956154', '100.398950', 1),
(38, 'LB10', 2, 4, 38, 32.31, 'pagambiran.jpg', '-0.979574', '100.404627', 1),
(39, 'LB11', 3, 4, 39, 51.93, 'pampangan.jpg', '-0.982536', '100.389668', 1),
(40, 'LB12', 3, 4, 40, 55.35, 'parak_laweh.jpg', '-0.967605', '100.393295', 1),
(41, 'LB13', 3, 4, 41, 125.37, 'tanah_sirah.jpg', '-0.948735', '100.410169', 1),
(42, 'LB14', 3, 4, 42, 97.02, 'tanjung_saba.jpg', '-0.955929', '100.405589', 1),
(43, 'LK01', 2, 11, 43, 171.54, 'bandar_buat.jpg', '-0.949571', '100.433495', 1),
(44, 'LK02', 2, 11, 44, 42.75, 'batu_gadang.jpg', '-0.973426', '100.477214', 1),
(45, 'LK03', 2, 11, 45, 150.03, 'beringin.jpg', '-0.965833', '100.447376', 1),
(46, 'LK04', 2, 11, 46, 127.71, 'indarung.jpg', '-0.951189', '100.479855', 1),
(47, 'LK05', 2, 11, 47, 95.04, 'koto_lalang.jpg', '-0.955986', '100.431472', 1),
(48, 'LK06', 3, 11, 48, 80.64, 'padang_besi.jpg', '-0.953473', '100.453907', 1),
(49, 'LK07', 2, 11, 49, 46.08, 'tarantang.jpg', '-0.968823', '100.434077', 1),
(50, 'NA01', 3, 5, 50, 136.35, 'gurun_laweh.jpg', '-0.907004', '100.378150', 1),
(51, 'NA02', 3, 5, 51, 89.82, 'kampung_lapai.jpg', '-0.904426', '100.358613', 1),
(52, 'NA03', 3, 5, 52, 125.1, 'kampung_olo.jpg', '-0.902024', '100.364288', 1),
(53, 'NA04', 3, 5, 53, 326.07, 'kurao_pagang.jpg', '-0.887550', '100.370965', 1),
(54, 'NA05', 3, 5, 54, 177.3, 'surau_gadang.jpg', '-0.896077', '100.370702', 1),
(55, 'NA06', 3, 5, 55, 72.79, 'tabiang_banda_gadang.jpg', '-0.913355', '100.373274', 1),
(56, 'PB01', 3, 6, 56, 49.86, 'belakang_tangsi.jpg', '-0.954670', '100.357187', 1),
(57, 'PB02', 3, 6, 57, 19.26, 'berok_nipah.jpg', '-0.963023', '100.354672', 1),
(58, 'PB03', 3, 6, 58, 49.77, 'flamboyan_baru.jpg', '-0.924993', '100.354529', 1),
(59, 'PB04', 3, 6, 59, 63.99, 'kampung_jao.jpg', '-0.945905', '100.359228', 1),
(60, 'PB05', 2, 6, 60, 37.62, 'kampung_pondok.jpg', '-0.957277', '100.359401', 1),
(61, 'PB06', 3, 6, 61, 50.4, 'olo.jpg', '-0.946677', '100.353880', 1),
(62, 'PB07', 3, 6, 62, 64.26, 'padang_pasir.jpg', '-0.938811', '100.357514', 1),
(63, 'PB08', 3, 6, 63, 51.39, 'purus.jpg', '-0.937890', '100.352619', 1),
(64, 'PB09', 3, 6, 64, 59.22, 'rimbo_kaluang.jpg', '-0.928482', '100.356065', 1),
(65, 'PB10', 3, 6, 65, 36.9, 'ujung_gurun.jpg', '-0.932557', '100.356959', 1),
(66, 'PS01', 2, 7, 66, 39.78, 'air_manis.jpg', '-0.985569', '100.367890', 1),
(67, 'PS02', 3, 7, 67, 22.23, 'alang_laweh.jpg', '-0.953146', '100.365851', 1),
(68, 'PS03', 2, 7, 68, 0.09, 'batang_arau.jpg', '-0.967657', '100.356207', 1),
(69, 'PS04', 3, 7, 69, 32.24, 'belakang_pondok.jpg', '-0.955207', '100.362142', 1),
(70, 'PS05', 2, 7, 70, 0.54, 'bukik_gado.jpg', '-0.972200', '100.361090', 1),
(71, 'PS06', 3, 7, 71, 17.82, 'mato_aie.jpg', '-0.974555', '100.375205', 1),
(72, 'PS07', 3, 7, 72, 20.52, 'pasa_gadang.jpg', '-0.959974', '100.368467', 1),
(73, 'PS08', 3, 7, 73, 19.08, 'parak_rumbio.jpg', '-0.957019', '100.366240', 1),
(74, 'PS09', 3, 7, 74, 22.41, 'rawang.jpg', '-0.984054', '100.379620', 1),
(75, 'PS10', 3, 7, 75, 22.77, 'seberang_padang.jpg', '-0.958161', '100.375191', 1),
(76, 'PS11', 2, 7, 76, 1.35, 'seberang_palinggam.jpg', '-0.965297', '100.369204', 1),
(77, 'PS12', 2, 7, 77, 14.58, 'taluak_bayua.jpg', '-1.004123', '100.395519', 1),
(78, 'PT01', 2, 8, 78, 102.96, 'andalas.jpg', '-0.939038', '100.380924', 1),
(79, 'PT02', 3, 8, 79, 84.6, 'ganting_parak_gadang.jpg', '-0.950222', '100.372921', 1),
(80, 'PT03', 3, 8, 80, 90.9, 'jati.jpg', '-0.934592', '100.369673', 1),
(81, 'PT04', 3, 8, 81, 71.46, 'jati_baru.jpg', '-0.936731', '100.363874', 1),
(82, 'PT05', 2, 8, 82, 57.24, 'kubu_marapalam.jpg', '-0.951695', '100.386332', 1),
(83, 'PT06', 2, 8, 83, 177.12, 'kubu_parak_karakah.jpg', '-0.945422', '100.391034', 1),
(84, 'PT07', 3, 8, 84, 62.82, 'parak_gadang_timur..jpg', '-0.954871', '100.382894', 1),
(85, 'PT08', 3, 8, 85, 58.32, 'sawahan.jpg', '-0.946248', '100.365488', 1),
(86, 'PT09', 3, 8, 86, 75.6, 'sawahan_timur.jpg', '-0.942555', '100.371669', 1),
(87, 'PT10', 2, 8, 87, 45.9, 'simpang_haru.jpg', '-0.946130', '100.378583', 1),
(88, 'PU01', 3, 9, 88, 111.24, 'air_tawar_barat.jpg', '-0.895138', '100.347955', 1),
(89, 'PU02', 3, 9, 89, 66.96, 'air_tawar_timur.jpg', '-0.895314', '100.354362', 1),
(90, 'PU03', 3, 9, 90, 176.4, 'alai_parak_kopi.jpg', '-0.926376', '100.369759', 1),
(91, 'PU04', 3, 9, 91, 134.1, 'gunung_pangilun.jpg', '-0.914042', '100.363458', 1),
(92, 'PU05', 3, 9, 92, 108.99, 'lolong_belanti.jpg', '-0.919910', '100.354620', 1),
(93, 'PU06', 3, 9, 93, 93.78, 'ulak_karang_selatan.jpg', '-0.912798', '100.351479', 1),
(94, 'PU07', 3, 9, 94, 80.19, 'ulak_karang_utara.jpg', '-0.907987', '100.347059', 1),
(95, 'PA01', 2, 10, 95, 170.55, 'binuang.jpg', '-0.933557', '100.421673', 1),
(96, 'PA02', 2, 10, 96, 102.24, 'cupak_tangah.jpg', '-0.934146', '100.430909', 1),
(97, 'PA03', 2, 10, 97, 104.22, 'kapala_koto.jpg', '-0.934190', '100.453806', 1),
(98, 'PA04', 2, 10, 98, 71.73, 'koto_luar.jpg', '-0.927878', '100.438527', 1),
(99, 'PA05', 2, 10, 99, 90.9, 'lambung_bukit.jpg', '-0.842527', '100.479146', 1),
(100, 'PA06', 2, 10, 100, 167.76, 'limau_manis.jpg', '-0.888638', '100.491468', 1),
(101, 'PA07', 2, 10, 101, 96.48, 'limau_manis_selatan.jpg', '-0.928730', '100.487131', 1),
(102, 'PA08', 2, 10, 102, 99.81, 'piai_tangah.jpg', '-0.944440', '100.423851', 1),
(103, 'PA09', 2, 10, 103, 232.38, 'pisang.jpg', '-0.940709', '100.407543', 1);

-- --------------------------------------------------------

--
-- Table structure for table `informasi`
--

CREATE TABLE `informasi` (
  `id_info` int(11) NOT NULL,
  `info_judul` varchar(255) NOT NULL,
  `info_isi` text NOT NULL,
  `info_tgl` date NOT NULL,
  `foto` varchar(255) NOT NULL,
  `id_kelurahan` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informasi`
--

INSERT INTO `informasi` (`id_info`, `info_judul`, `info_isi`, `info_tgl`, `foto`, `id_kelurahan`, `id_admin`) VALUES
(1, 'Informasi Banjir Di Sawahan', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cursus turpis massa tincidunt dui ut ornare. Enim praesent elementum facilisis leo vel. Id aliquet lectus proin nibh nisl condimentum id venenatis. Ut eu sem integer vitae. Elementum nisi quis eleifend quam. Eu turpis egestas pretium aenean pharetra magna ac placerat vestibulum. Suspendisse interdum consectetur libero id faucibus nisl tincidunt.', '2021-04-13', 'jati.jpg', 80, 2),
(2, 'Informasi Banjir Di Kuranji', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cursus turpis massa tincidunt dui ut ornare. Enim praesent elementum facilisis leo vel. Id aliquet lectus proin nibh nisl condimentum id venenatis. Ut eu sem integer vitae. Elementum nisi quis eleifend quam. Eu turpis egestas pretium aenean pharetra magna ac placerat vestibulum. Suspendisse interdum consectetur libero id faucibus nisl tincidunt.', '2021-04-02', 'Kuranji.jpg', 25, 2),
(3, 'test', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2020-10-11', 'jati.jpg', 80, 2);

-- --------------------------------------------------------

--
-- Table structure for table `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id_kecamatan` int(11) NOT NULL,
  `nama_kecamatan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kecamatan`
--

INSERT INTO `kecamatan` (`id_kecamatan`, `nama_kecamatan`) VALUES
(1, 'Bungus Teluk Kabung'),
(2, 'Koto Tangah'),
(3, 'Kuranji'),
(4, 'Lubuk Begalung'),
(5, 'Nanggalo'),
(6, 'Padang Barat'),
(7, 'Padang Selatan'),
(8, 'Padang Timur'),
(9, 'Padang Utara'),
(10, 'Pauh'),
(11, 'Lubuk Kilangan');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `kode_kelas` varchar(5) NOT NULL,
  `nama_kelas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kode_kelas`, `nama_kelas`) VALUES
(1, 'B1', 'Rendah'),
(2, 'B2', 'Sedang'),
(3, 'B3', 'Tinggi');

-- --------------------------------------------------------

--
-- Table structure for table `kelurahan`
--

CREATE TABLE `kelurahan` (
  `id_kelurahan` int(11) NOT NULL,
  `id_kecamatan` int(11) NOT NULL,
  `nama_kelurahan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelurahan`
--

INSERT INTO `kelurahan` (`id_kelurahan`, `id_kecamatan`, `nama_kelurahan`) VALUES
(1, 1, 'Bungus Barat'),
(2, 1, 'Bungus Selatan'),
(3, 1, 'Bungus Timur'),
(4, 1, 'Teluk Kabung Selatan'),
(5, 1, 'Teluk Kabung Tengah'),
(6, 1, 'Teluk Kabung Utara'),
(7, 2, 'Air Pacah'),
(8, 2, 'Balai Gadang'),
(9, 2, 'Batang Kabung'),
(10, 2, 'Batipuh Panjang'),
(11, 2, 'Bungo Pasang'),
(12, 2, 'Dadok Tunggul Hitam'),
(13, 2, 'Koto Panjang Ikua Koto'),
(14, 2, 'Koto Pulai'),
(15, 2, 'Lubuk Buaya'),
(16, 2, 'Lubuk Minturun'),
(17, 2, 'Padang Sarai'),
(18, 2, 'Parupuk Tabing'),
(19, 2, 'Pasir Nan Tigo'),
(20, 3, 'Ampang'),
(21, 3, 'Anduring'),
(22, 3, 'Gunung Sarik'),
(23, 3, 'Kalumbuk'),
(24, 3, 'Korong Gadang'),
(25, 3, 'Kuranji'),
(26, 3, 'Lubuk Lintah'),
(27, 3, 'Pasar Ambacang'),
(28, 3, 'Sungai Sapih'),
(29, 4, 'Banuaran Nan XX'),
(30, 4, 'Batuang Taba Nan XX'),
(31, 4, 'Cengkeh Nan XX'),
(32, 4, 'Gates Nan XX'),
(33, 4, 'Gurun Laweh Nan XX'),
(34, 4, 'Kampung Baru Nan XX'),
(35, 4, 'Kampung Jua Nan XX'),
(36, 4, 'Koto Baru Nan XX'),
(37, 4, 'Lubuk Begalung Nan XX'),
(38, 4, 'Pagambiran Ampalu Nan XX'),
(39, 4, 'Pampangan Nan XX'),
(40, 4, 'Parak Laweh Pulau Air Nan XX'),
(41, 4, 'Tanah Sirah Piai Nan XX'),
(42, 4, 'Tanjung Saba Pitameh Nan XX'),
(43, 11, 'Bandar Buat'),
(44, 11, 'Batu Gadang'),
(45, 11, 'Beringin'),
(46, 11, 'Indarung'),
(47, 11, 'Koto Lalang'),
(48, 11, 'Padang Besi'),
(49, 11, 'Tarantang'),
(50, 5, 'Gurun Laweh'),
(51, 5, 'Kampung Lapai Baru'),
(52, 5, 'Kampung Olo'),
(53, 5, 'Kurao Pagang'),
(54, 5, 'Surau Gadang'),
(55, 5, 'Tabiang Banda Gadang'),
(56, 6, 'Belakang Tangsi'),
(57, 6, 'Berok Nipah'),
(58, 6, 'Flamboyan Baru'),
(59, 6, 'Kampung Jao'),
(60, 6, 'Kampung Pondok'),
(61, 6, 'Olo'),
(62, 6, 'Padang Pasir'),
(63, 6, 'Purus'),
(64, 6, 'Rimbo Kaluang'),
(65, 6, 'Ujung Gurun'),
(66, 7, 'Air Manis'),
(67, 7, 'Alang Laweh'),
(68, 7, 'Batang Arau'),
(69, 7, 'Belakang Pondok'),
(70, 7, 'Bukik Gado Gado'),
(71, 7, 'Mato Aie'),
(72, 7, 'Pasa Gadang'),
(73, 7, 'Ranah Parak Rumbio'),
(74, 7, 'Rawang'),
(75, 7, 'Seberang Padang'),
(76, 7, 'Seberang Palinggam'),
(77, 7, 'Taluak Bayua'),
(78, 8, 'Andalas'),
(79, 8, 'Ganting Parak Gadang'),
(80, 8, 'Jati'),
(81, 8, 'Jati Baru'),
(82, 8, 'Kubu Marapalam'),
(83, 8, 'Kubu Parak Karakah'),
(84, 8, 'Parak Gadang Timur'),
(85, 8, 'Sawahan'),
(86, 8, 'Sawahan Timur'),
(87, 8, 'Simpang Haru'),
(88, 9, 'Air Tawar Barat'),
(89, 9, 'Air Tawar Timur'),
(90, 9, 'Alai Parak Kopi'),
(91, 9, 'Gunung Pangilun'),
(92, 9, 'Lolong Belanti'),
(93, 9, 'Ulak Karang Selatan'),
(94, 9, 'Ulak Karang Utara'),
(95, 10, 'Binuang Kampung Dalam'),
(96, 10, 'Cupak Tangah'),
(97, 10, 'Kapala Koto'),
(98, 10, 'Koto Luar'),
(99, 10, 'Lambung Bukit'),
(100, 10, 'Limau Manis'),
(101, 10, 'Limau Manis Selatan'),
(102, 10, 'Piai Tangah'),
(103, 10, 'Pisang');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `daerah`
--
ALTER TABLE `daerah`
  ADD PRIMARY KEY (`id_daerah`);

--
-- Indexes for table `informasi`
--
ALTER TABLE `informasi`
  ADD PRIMARY KEY (`id_info`);

--
-- Indexes for table `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id_kecamatan`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `kelurahan`
--
ALTER TABLE `kelurahan`
  ADD PRIMARY KEY (`id_kelurahan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `daerah`
--
ALTER TABLE `daerah`
  MODIFY `id_daerah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `informasi`
--
ALTER TABLE `informasi`
  MODIFY `id_info` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kecamatan`
--
ALTER TABLE `kecamatan`
  MODIFY `id_kecamatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kelurahan`
--
ALTER TABLE `kelurahan`
  MODIFY `id_kelurahan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
