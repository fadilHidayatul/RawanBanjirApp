<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,404,'Page Not Found');
}else {
    $query = "SELECT * FROM informasi ORDER BY info_tgl DESC";

    $stmt = $conn->prepare($query);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);

            $item = array(
                "id_info" => $row['id_info'],
                "judul" => $row['info_judul'],
                "isi" => $row['info_isi'],
                "tgl" => $row['info_tgl'],
                "foto" => $row['foto'],
                "id_admin" => $row['id_admin']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data ada', $data);
    }else {
        $returnData = msg(0,201,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>