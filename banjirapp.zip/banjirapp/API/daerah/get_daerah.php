<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();
    
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['id_kecamatan']) || !isset($_POST['id_kelurahan']) || empty(trim($_POST['id_kecamatan'])) || empty(trim($_POST['id_kelurahan']))
) {
    $returnData = msg(0,422,'Harap cek parameter yang dimasukkan');
}else {
    $idkec = $_POST['id_kecamatan'];
    $idkel = $_POST['id_kelurahan'];

    $query = "SELECT * FROM daerah d
             LEFT JOIN kecamatan kc ON d.id_kecamatan = kc.id_kecamatan
             LEFT JOIN kelurahan kl ON d.id_kelurahan = kl.id_kelurahan
             LEFT JOIN kelas kls ON d.id_kelas = kls.id_kelas
             WHERE d.id_kecamatan = :idkec AND d.id_kelurahan = :idkel";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":idkec", $idkec);
    $stmt->bindParam(":idkel", $idkel);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);

            $item = array(
                "id_daerah" => $row['id_daerah'],
                "kode_daerah" => $row['kode_daerah'],
                "kode_bahaya" => $row['kode_kelas'],
                "tingkat_bahaya" => $row['nama_kelas'],
                "nama_kecamatan" => $row['nama_kecamatan'],
                "nama_kelurahan" => $row['nama_kelurahan'],
                "luas" => $row['luas_bahaya'],
                "foto" => $row['foto'],
                "lat" => $row['lat'],
                "lgt" => $row['lng'],
                "id_admin" => $row['id_admin']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data Ada', $data);
    }else {
        $returnData = msg(0,201,'Data Tidak Ada');
    }
}


echo json_encode($returnData);
?>