<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,404,'Page not found');
}else {
    $query = "SELECT * FROM kecamatan ORDER BY nama_kecamatan ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id_kecamatan" => $row['id_kecamatan'],
                "nama_kecamatan" => $row['nama_kecamatan']
            );

            array_push($data["DATA"], $item);
        }
        $returnData = msg(1,200,'Data Ada', $data);
    }else{
        $returnData = msg(0,201,'Data Tidak Ada');
    }
}

echo json_encode($returnData);
?>